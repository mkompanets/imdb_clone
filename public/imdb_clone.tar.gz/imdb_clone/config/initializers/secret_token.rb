# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
ImdbClone::Application.config.secret_token = '398461bc3ccb3ae53aa72978ef000b3a3500640abc5dc2abf2c794a04661876e7d90a009b341b6342c973226890cc72647d0481889cebdfc2e5a4be2492c7b20'
