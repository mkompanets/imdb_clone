class Director < Occupation
end