class Actor < Occupation
  has_many :characters
end