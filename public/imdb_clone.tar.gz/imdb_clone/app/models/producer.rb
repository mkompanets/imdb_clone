class Producer < Occupation
end