class Writer < Occupation
end